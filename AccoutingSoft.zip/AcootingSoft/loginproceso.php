<?php
    session_start();
    include_once 'model/conexion.php';
    $usuario = $_POST['usuario'];
    $pass = $_POST['clave'];
    $sentencia = $bd->prepare('SELECT * FROM tb_aprendiz WHERE apr_usuario = ? AND apr_password = ?;');

    $sentencia->execute([$usuario, $pass]);
    $datos = $sentencia->fetch(PDO::FETCH_OBJ);
    //print_r($datos);

    if($datos === FALSE){
        $sentencia2 = $bd->prepare('SELECT * FROM tb_instructor WHERE in_usuario = ? AND in_password = ?;');
        $sentencia2->execute([$usuario, $pass]);
        $datos2 = $sentencia2->fetch(PDO::FETCH_OBJ);
         if($datos2 === FALSE){
              $sentencia3 = $bd->prepare('SELECT * FROM tb_administrador WHERE ad_usuario = ? AND ad_password = ?;');
                $sentencia3->execute([$usuario, $pass]);
                $datos3 = $sentencia3->fetch(PDO::FETCH_OBJ);
             if($datos3 === FALSE){
                 header('Location: index.php');  
             }elseif($sentencia3->rowCount() ==1 ){
                 header('Location: ./vista/aprendiz.php'); 
             }
         }elseif($sentencia2->rowCount() == 1){
              header('Location: ./vista/aprendiz.php'); 
         } 
    }elseif($sentencia->rowCount() == 1){
        header('Location: ./vista/aprendiz.php');      
    }
?>
    
    
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/cuerpo.css" >

    <title>Accounting Soft</title>
  </head>
  <body>
  <div class="container-fluid">
       
    
    <div class="row" id="principal">
      <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10"> 
        <img src="../img/Logonew.png">

      </div>
      <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2" id="centrado"> 
        
        <svg class="bi bi-person-square" id="icono" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
          <path fill-rule="evenodd" d="M14 1H2a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z"/>
          <path fill-rule="evenodd" d="M2 15v-1c0-1 1-4 6-4s6 3 6 4v1H2zm6-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
        </svg>
        
      </div>
    </div>
    <div class="row align-items-start">
      <div class="col-3" id="secundario">
        <div class="col-12" >
          <input type="button" name="empresa" value="Empresas" id="redondeado" onclick="window.location='aprendiz.php'">
        </div>
        <div class="col-12">
          <input type="button" name="instructor" value="Instructor" id="redondeado" onclick="window.location='aprinstructor.php'">
        </div>
        <div class="col-12">
          <input type="button" name="resultado" value="Resultado" id="redondeado" onclick="window.location='aprinstructor.php'">
        </div>
        <div class="col-12">
          <input type="button" name="comentarios" value="Comentarios" id="redondeado" onclick="window.location='aprinstructor.php'">
        </div>
        <div class="col-12">
          <input type="button" name="foro" value="Foro" id="redondeado">
        </div>
        <br>
        <br>
      </div>
      <div class="col-9">
        <div class="row" id="caja">
          <div class="col-12">
            <br>
            <h3>Comentarios</h3>
          </div>
          <div class="col-12">
            <div class="row">
              <div class="col-12" id="caja2">
                <div class="row">
                  <div class="col-4">
                    <h4>Instructor</h4>
                    <h4></h4>
                  </div>
                  <div class="col-4">
                    <h4>Empresa</h4>
                    <h4></h4>
                  </div>
                  <div class="col-2">
                    <h4>Nota</h4>
                    <h4></h4>
                  </div>
                  <div class="col-2" id="centrado">
                    <button type="submit" data-toggle="modal" data-target="#exampleModal"><svg class="bi bi-eye" id="icono2" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                      <path fill-rule="evenodd" d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8zM1.173 8a13.134 13.134 0 0 0 1.66 2.043C4.12 11.332 5.88 12.5 8 12.5c2.12 0 3.879-1.168 5.168-2.457A13.134 13.134 0 0 0 14.828 8a13.133 13.133 0 0 0-1.66-2.043C11.879 4.668 10.119 3.5 8 3.5c-2.12 0-3.879 1.168-5.168 2.457A13.133 13.133 0 0 0 1.172 8z"/>
                      <path fill-rule="evenodd" d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0z"/></svg></button>
                    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Comentario</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form>
                                    <div class="row">
                                        <h2>Comentario</h2>
                                </form>
                            </div>
                            <div class="modal-footer">
                                
                                <button type="button" class="btn btn-primary">Aceptar</button>
                            </div>
                            </div>
                        </div>
                        </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="row align-items-start">
      <div class="col-12" id="secundario">
        <h1>footer</h1>
      </div>
    </div>
  </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  </body>
</html>
<?php
    $contrasena = '';
    $usuario = 'root';
    $nombredb= 'db_edu_erp';
    
    try{
     $bd = new PDO('mysql:host=localhost;
                    dbname='.$nombredb,
                    $usuario,$contrasena
                   );
    } catch (Exception $e){
        echo "Error al conectarse ".$e->getMessage();
    }
    
?>


<html>
<head>
	<title>Acooting Soft</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="./css/esti.css">
</head>
<body>
 	<nav class="navbar navbar-expand-lg navbar-dark barra">
  		<a class="navbar-brand" href="#">Accouting Soft</a>
  		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    		<span class="navbar-toggler-icon"></span>
  		</button>
	  <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto"></ul>
	      <li class="nav-item active">
	        <a class="nav-link" href="#" data-toggle="modal" data-target="#exampleModal">Ingresar</a>
	      </li>
	      <li class="nav-item active">
	        <a class="nav-link" href="#" data-toggle="modal" data-target="#exampleModal2">Registrarse </a>
	      </li>
	  </div>
	</nav>
    <div class="row align-items-center">
        <div class="imagen col-xl-12 col-md-12">
            <img src="img/principal.jpg" class="img-fluid" alt="Responsive image">
        </div>
        <div class="texto col-xl-6 col-lg-6 col-md-6 ml-5">
            <p>Desarrolla modelos empresariales
                y únete al mundo de la contabilidad
                con ayuda de instructores altamente 
                capacitdos
            </p>
        </div>
        <div class="boton col-xl-4">
            <button type="submit" class="btn pl-2 pr-2 col-3  bot">Inscribete</button>
        </div>
    </div>
    <div class="container mt-4">    
        <h1 class="titulo mt-3">¿Cómo funciona?</h1>
        <div class="row mt-5 align-items-center">
            <div class="imagen2 col-xl-6 col-lg-6 col-md-6">
                <img src="img/inovar.jpg" class="img-fluid" alt="Responsive image">
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6">
                <h2 class="titulo2">1 Crea una empresa:</h2>
                <h3 class="tex">En Acooting Soft podreas crear
                    cualquier tipo de empresa para 
                    iniciar el desarrollo de su contabilidad
                   </h3>
            </div>
        </div>
        <div class="row mt-5 align-items-center">
            <div class="col-xl-6 col-lg-6 col-md-6">
                <h2 class="titulo2">2 Ten asesoría:</h2>
                <h3 class="tex">Tendrás una asesoría en todo el 
                    desarrollo contable de tu empresa de
                    la mano de los instructores del SENA
                </h3>
            </div>
            <div class="imagen2 col-xl-6 col-lg-6 col-md-6">
                <img src="img/asesoria.jpg" class="img-fluid" alt="Responsive image">
            </div>
        </div>
        <div class="row mt-5 align-items-center">
            <div class="imagen2 col-xl-6 col-lg-6 col-md-6">
                <img src="img/resultados.jpg" class="img-fluid" alt="Responsive image">
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6">
                <h2 class="titulo2">3 Conoce tus resultados:</h2>
                <h3 class="tex">Podrás ver el resultado de tu 
                    proceso, por medio de calificaciones 
                    y observaciones por parte de tu 
                    instructor
                   </h3>
            </div>
        </div>
    </div>
    <div class="container mt-5">
        <h1 class="titulo">Beneficios</h1>
        <div class="row mt-5">
            <div class="col-xl-3 col-lg-3 col-md-12">
                <img src="img/acceso.jpg"  class="img-fluid" alt="Responsive image"> 
            </div>
            <div class="col-xl-3 col-lg-3 col-md-3">
                <h2 class="titulo2">Acceso:</h2>
                <p class="tex">
                    Podrás ingresar al 
                    sistema las 24 horas del 
                    día sin preocuparte por 
                    el tiempo
                </p>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-3">
                <img src="img/seguridad.jpg"  class="img-fluid" alt="Responsive image">
            </div>
            <div class="col-xl-3 col-lg-3 col-md-3">
                <h2 class="titulo2">Seguridad:</h2>
                <p class="tex">
                    Tendrás la tranquilidad
                    de ingresar a un 
                    sistema que protege 
                    tu información
                </p>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-12 mt-5">
                <img src="img/asesoria2.jpg"  class="img-fluid" alt="Responsive image"> 
            </div>
            <div class="col-xl-3 col-lg-3 col-md-3 mt-5">
                <h2 class="titulo2">Asesoria:</h2>
                <p class="tex">
                    Contarás con la mejor
                    asesoría por parte del 
                    instructor para tu 
                    diseño contable
                </p>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-3 mt-4">
                <img src="img/facil.jpg"  class="img-fluid" alt="Responsive image">
            </div>
            <div class="col-xl-3 col-lg-3 col-md-3 mt-5">
                <h2 class="titulo2">Simplicidad:</h2>
                <p class="tex">
                    Manejarás un software 
                    entendible y de fácil 
                    manejo 
                </p>
            </div>
        </div>
    </div>
    <div class="pie mt-5"> 
        <div class="container">
            <div class="row">
                <div class=" my-5 col-xl-4 col-lg-4 col-md-4">
                    <h5>Acooting soft © ><br>
                    Todos los derechos reservados</h5>
                </div>
                <div class=" my-3 col-xl-4 col-lg-4 col-md-4">
                    <h5>Sitio desarrollado para <br>
                    uso exclusivo de aprendices del sena<br>
                    para el desarrollo de su proseso de aprendizaje.</h5>
                </div>
                <div class=" my-4 col-xl-4 col-lg-4 col-md-4">
                    <h5>Contactanos: <br>
                    3186360429<br>
                    Acootingsoft@gmail.com</h5>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="tp">
            <h5 class="titulomodal">Iniciar Sesión</h5>
          </div>
          <div class="modal-body">
              <div class="container">
                  <div class="row">
                      <form class="col-xl-12 col-lg-12 col-md-12 " method="post" action="loginproceso.php">
                          <input type="text" class="inp col-xl-12 mt-2 col-lg-12 col-md-12" placeholder="Usuario:" name="usuario">
                          <input type="Password" class="inp col-xl-12 mt-3 col-lg-12 col-md-12" placeholder="Contraseña:" name="clave">
                          <input type="submit" class="btnl col-xl-12 col-lg-12 col-md12 col-sm-12 col-xs-12 mt-4 p-2" value="Ingresar">
                      </form>
                  </div>
              </div>
          </div>
        </div>
      </div>
    </div>
    <div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
            <div class="tp">
                <h5 class="titulomodal">Registrarse</h5>
            </div>
          <div class="modal-body">
            <div class="container">
                  <div class="row">
                      <form class="col-xl-12 col-lg-12 col-md-12">
                          <input type="text" class="inp col-xl-12 mt-2 col-lg-12 col-md-12" placeholder="Documento:">
                          <input type="submit" class="btnl col-xl-12 col-lg-12 col-md12 col-sm-12 col-xs-12 mt-4 p-2" value="Buscar">
                      </form>
                  </div>
              </div>
          </div>
        </div>
      </div>
    </div>
</body>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</html>